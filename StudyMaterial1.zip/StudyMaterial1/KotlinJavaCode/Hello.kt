
package learnKotlin

fun main() {
	println("HelloWorld!!!")
}

/*
public class HelloKt {
	public static void main() {
		System.out.println("HelloWorld!!!")
	}
}
*/
