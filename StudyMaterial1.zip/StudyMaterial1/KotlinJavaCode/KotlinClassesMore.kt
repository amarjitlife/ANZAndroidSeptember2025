
package learnKotlin

import java.util.HashSet

//_____________________________________________________________

// Secondary Constructors
open class Shape1 {
    // Secondary Constructors
    constructor(size: Int) {
        // ...
    }
    // Secondary Constructors
    constructor(size: Int, color: String) : this(size) {
        // ...
    }
}

class Circle1 : Shape1 {
    // Secondary Constructors
    constructor(size: Int) : super(size) {
        // ...
    }

    // Secondary Constructors
    constructor(size: Int, color: String) : super(size, color) {
        // ...
    }
}

//_____________________________________________________________

enum class Colour { RED, GREEN, BLUE, WHITE, BLACK }

open class Shape {
    var boundaryColor: Colour
    var fillColor : Colour

	// Delegating Initialisation To Major Constructor
    constructor( ): this(boundaryColor = Colour.BLACK, fillColor = Colour.WHITE ) {
         // this.boundaryColor  = Colour.BLACK
         // this.fillColor      = Colour.WHITE
    }
    // Delegating Initialisation To Major Constructor
    constructor( boundaryColor : Colour ) : this( boundaryColor, Colour.WHITE) {}
    
    // Major Constructor
    constructor( boundaryColor : Colour, fillColor: Colour ) {
    	this.boundaryColor = boundaryColor
    	this.fillColor = fillColor
    }

    override fun toString() = "Shape(boundaryColor=$boundaryColor, fillColor=$fillColor)"
}

class Circle : Shape {
    var radius : Int 

	// Delegating Initialisation To Major Constructor
    constructor( boundaryColor : Colour ) : this( boundaryColor, Colour.WHITE, 0 ) { }
    
    // Delegating Initialisation To Major Constructor
    constructor( boundaryColor : Colour, fillColor : Colour ) : this( boundaryColor, fillColor, 0 ) { }

    // Major Constructor
    constructor( boundaryColor : Colour, fillColor : Colour, radius : Int ) : super(boundaryColor, fillColor) {
        this.radius = radius    
    }

    override fun toString() = "Circle(boundaryColor=$boundaryColor, fillColor=$fillColor, radius=$radius)"   
}

fun playWithShapes() {
    val shape = Shape( Colour.RED, Colour.GREEN )
    println( shape )

    val circle = Circle( Colour.RED, Colour.GREEN, 99 )
    println( circle )
}

//_____________________________________________________________
// DESIGN PRINCIPLE
//      Design Towards Interfaces Rather Than Concrete Classes
//          Interfaces Are Pure Abstract Classes
//          
//      Contract In System
//      Cantract Driven Design

// DESIGN PRACTICE
//      1. Always Prefer Composition Over Inheritance
//      2. Always Prefer Interfaces Over Abstract Classes
//      3. Always Prefer Abstact Classes Over Concrete Classes
//      4. Concerete Classes Are Last Choice

// Behaviour Driven Design: Behaviour
// What To Do?
interface Superpower {
    fun fly()
    fun saveWorld()
}

// class Spiderman {
//     fun fly()       { println("Fly Like Spiderman!") }
//     fun saveWorld() { println("saveWorld Like Spiderman!") }
// }

// How, When, Where, Which
class Spiderman : Superpower {
    override fun fly()       { println("Fly Like Spiderman!") }
    override fun saveWorld() { println("saveWorld Like Spiderman!") }
}

class Superman : Superpower {
    override fun fly()       { println("Fly Like Superman!") }
    override fun saveWorld() { println("saveWorld Like Superman!") }
}

open class Wonderwoman {
    open fun fly()       { println("Fly Like Wonderwoman!") }
    open fun saveWorld() { println("saveWorld Like Wonderwoman!") }
}

//_____________________________________________________________
// Using Mechanism: Inheritance

// class Human {
// class Human : Spiderman() {
// class Human : Superman() {    
class Human : Wonderwoman() {     
    override fun fly()       { super.fly()       }   // { println("Fly Like Human!") }
    override fun saveWorld() { super.saveWorld() }   // { println("saveWorld Like Human!") }
}

//_____________________________________________________________
// Using Mechanism Composition
//      Alternative To Inheritance

class HumanBetter {
    // val power = Spiderman()
    // val power = Superman()
    val power = Wonderwoman()

    fun fly()       { power.fly()       }   // { println("Fly Like Human!") }
    fun saveWorld() { power.saveWorld() }   // { println("saveWorld Like Human!") }
}

//_____________________________________________________________
// Using Mechanism Composition
//      Alternative To Inheritance
//      Always Prefer Composition Over Inheritance

// SOLID Principle
//      Open-Close Principle
//      Classes Must Be Open For Extension But Close For Modification
class HumanBest { // Delegator : Delegating Functionality To Delegate
    // power Is Delegate
    var power : Superpower? = null
    fun fly()       { power?.fly()       }   // { println("Fly Like Human!") }
    fun saveWorld() { power?.saveWorld() }   // { println("saveWorld Like Human!") }
}

//_____________________________________________________________
// Using Mechanism Composition

class HumanNew( power : Superpower ) : Superpower by power {
    // var power : Superpower? = null
    // fun fly()       { power?.fly()       }   // { println("Fly Like Human!") }
    // fun saveWorld() { power?.saveWorld() }   // { println("saveWorld Like Human!") }
}

//_____________________________________________________________

fun playWithHuman() {
    println("\nHuman....")
    val h = Human()

    h.fly() // Calling A Function fly()
    /// [ h Object ]  <----- Message fly ( PAYLOAD )
 
    h.saveWorld()

    println("\nHumanBetter....")
    val hb = HumanBetter()
    hb.fly()
    hb.saveWorld()

    println("\nHumanBest....")
    val hbb = HumanBest()

    hbb.power = Spiderman()
    hbb.fly()
    hbb.saveWorld()

    hbb.power = null
    hbb.fly()
    hbb.saveWorld()

    hbb.power = Superman()
    hbb.fly()
    hbb.saveWorld()

    val hn = HumanNew( Spiderman() )
    hn.fly()
    hn.saveWorld()
}

//_____________________________________________________________
//_____________________________________________________________

// import java.util.HashSet

class CountingSet<T>( val innerSet: MutableCollection<T> = HashSet<T>() ) : MutableCollection<T> by innerSet {

    var objectsAdded = 0

    override fun add(element: T): Boolean {
        objectsAdded++
        return innerSet.add(element)
    }

    override fun addAll(elements: Collection<T>): Boolean {
        objectsAdded += elements.size
        return innerSet.addAll(elements)
    }
}

fun classDelegationUsingTheByKeyword() {
    val cset = CountingSet<Int>()
    cset.addAll(listOf(1, 1, 2))
    println("${cset.objectsAdded} objects were added, ${cset.size} remain")
}

//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________
//_____________________________________________________________

fun main() {
    println("\nFunction: playWithShapes")
    playWithShapes()

    println("\nFunction: playWithHuman")
    playWithHuman()  

    println("\nFunction: classDelegationUsingTheByKeyword")
    classDelegationUsingTheByKeyword()
      
    // println("\nFunction: ")  
    // println("\nFunction: ")  
    // println("\nFunction: ")  
}


