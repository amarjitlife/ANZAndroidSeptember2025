plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android { // Enclosing Context 00
    namespace = "coroutines.concepts"
    compileSdk = 35

    defaultConfig { // Enclosed Context 01
        applicationId = "coroutines.concepts"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes { // Enclosed Context 02
        release { // Enclosed Context 02.1
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions { // Enclosed Context 03
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions { // Enclosed Context 04
        jvmTarget = "11"
    }
}

dependencies {

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
}