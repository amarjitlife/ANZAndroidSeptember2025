__________________________________________________________________________

Jetpack Compose Articles and Practice Assignments
__________________________________________________________________________

	https://developer.android.com/courses/pathways/android-architecture

	https://developer.android.com/codelabs/jetpack-compose-basics#0
	https://developer.android.com/courses/pathways/jetpack-compose-for-android-developers-2
	https://developer.android.com/courses/pathways/jetpack-compose-for-android-developers-3
	https://developer.android.com/courses/pathways/jetpack-compose-for-android-developers-4
	https://developer.android.com/courses/pathways/jetpack-compose-for-android-developers-5

	https://developer.android.com/courses/jetpack-compose/course

__________________________________________________________________________

Android Modern Architecture Articles and Practice Assignments
__________________________________________________________________________

	https://developer.android.com/topic/architecture
	https://developer.android.com/topic/architecture/recommendations

	https://developer.android.com/topic/architecture/ui-layer
	https://developer.android.com/topic/architecture/ui-layer/events
	https://developer.android.com/topic/architecture/ui-layer/stateholders
	https://developer.android.com/topic/architecture/ui-layer/state-production
	https://developer.android.com/topic/libraries/view-binding
	https://developer.android.com/topic/libraries/data-binding

	https://developer.android.com/topic/libraries/architecture/viewmodel
	https://developer.android.com/topic/libraries/architecture/livedata
	https://developer.android.com/topic/libraries/architecture/saving-states

__________________________________________________________________________

Android Modern Architecture, Compose and Coroutines Integration
__________________________________________________________________________

	Handling lifecycles with lifecycle-aware components
		https://developer.android.com/topic/libraries/architecture/lifecycle

	Integrate Lifecycle with Compose
		https://developer.android.com/topic/libraries/architecture/compose

	Use Kotlin coroutines with lifecycle-aware components
		https://developer.android.com/topic/libraries/architecture/coroutines

__________________________________________________________________________
__________________________________________________________________________
__________________________________________________________________________
__________________________________________________________________________

