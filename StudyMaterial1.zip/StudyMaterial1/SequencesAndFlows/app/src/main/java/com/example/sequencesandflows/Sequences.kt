package com.example.sequencesandflows

import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map

//_____________________________________________________

fun String.filter(predicate: (Char) -> Boolean ) : String {
    val sb = StringBuilder()
    for ( index in 0 until length ) {
        val element = get( index )
        if ( predicate( element ) ) sb.append( element )
    }
    return  sb.toString()
}

fun playWithHoF() {
    val someString = "ABCabcmu2345MUK"
    var result = someString.filter( { character: Char -> character in 'a'..'z'}  )
    println("Result : $result")

    result = someString.filter {
        character: Char -> character in
        'a'..'z'
    }
    println("Result : $result")

    result = someString.filter {
            it in 'a'..'z'
    }
    println("Result : $result")

    result = someString.filter( { character: Char -> character in 'A'..'Z'}  )
    println("Result : $result")

    result = someString.filter {
        it in 'A'..'Z'
    }
    println("Result : $result")

    result = someString.filter( { character: Char -> character in '0'..'9'}  )
    println("Result : $result")
}

//_____________________________________________________

fun playWithIterators() {
//    val numbers = listOf(10, 20, 30, 40, -10, 44, 50, -20, 55, 22 )
    val numbers = listOf(-10, 44, -20, 55, 22 )

    numbers.filter {
        print("Filter, ")
        it > 0
    }.map {
        print("Map, ")
        it.toString()
    }.forEach {
        print("ForEach, ")
    }
}

//_____________________________________________________

fun generatorFibbonaccis() = sequence {
    print("Suspending 1...")
    yield( 0L ) // Function Will Suspend Execution
    var current = 0L
    var next = 1L

    while( true ) {
        print("Suspending 2...")
        yield( next )
        val temp = current + next
        current = next
        next = temp
    }
}

fun playWithGenerator() {
//    val sequence = generatorFibbonaccis().take( 10 )
    val sequence = generatorFibbonaccis()
    sequence.forEach {
        println("Number: $it")
    }
}

//_____________________________________________________

@DelicateCoroutinesApi
fun playWithFlows() {
    val flowOfStrings = flow {
        emit(" ")
        for( number in 0..30 ) {
            emit("Emitting: $number")
        }
    }

    GlobalScope.launch {
        flowOfStrings
            .map { it.split(" ") }
            .map { it[1] }
            .catch {
                it.printStackTrace()
                emit("Fallback")
            }
            .flowOn( Dispatchers.Default )
            .collect { println( it ) }
        println("Finished...")
    }

    Thread.sleep( 2000 )
}

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________

fun main() {
    println("\nFunction: playWithIterators")
    playWithIterators()

    println("\nFunction: playWithHoF")
    playWithHoF()

//    println("\nFunction: playWithGenerator")
//    playWithGenerator()

    println("\nFunction: playWithFlows")
    playWithFlows()
//    println("\nFunction: ")
//    println("\nFunction: ")
//    println("\nFunction: ")
}